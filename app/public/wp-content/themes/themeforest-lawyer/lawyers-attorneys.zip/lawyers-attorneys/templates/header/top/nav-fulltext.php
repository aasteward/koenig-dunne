<div class="grid-1-1" id="top-nav-text">
	<?php echo do_shortcode( wpv_get_option( 'top-bar-text' ) ) // xss ok ?>
</div>