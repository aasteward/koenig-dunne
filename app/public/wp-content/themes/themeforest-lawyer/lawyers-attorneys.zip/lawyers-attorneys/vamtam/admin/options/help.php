<?php
return array(
	'name' => __( 'Help', 'lawyers-attorneys' ),
	'auto' => true,
	'config' => array(

		array(
			'name' => __( 'Help', 'lawyers-attorneys' ),
			'type' => 'title',
			'desc' => '',
		),

		array(
			'name' => __( 'Help', 'lawyers-attorneys' ),
			'type' => 'start',
			'nosave' => true,
		),
//----
		array(
			'type' => 'docs',
		),

			array(
				'type' => 'end',
			),
	),
);