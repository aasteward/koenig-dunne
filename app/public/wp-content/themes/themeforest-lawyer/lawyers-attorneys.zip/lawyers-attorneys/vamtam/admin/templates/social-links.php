<script type="text/html" id="wpv-tmpl-social-link">
	<td>
		<span class="icon-preview"></span>
		<a href="#" class="icon-change"><%= window.WPV_ADMIN.iconChange %></a>
		<input type="hidden" name="icon-name" />
	</td>
	<td><input type="text" name="icon-text" /></td>
	<td><input type="text" name="icon-link" /></td>
</script>

<script type="text/html" id="wpv-tmpl-social-links">
	<table class="current-icons">
		<tr>
			<th><%= window.WPV_ADMIN.iconName %></th>
			<th><%= window.WPV_ADMIN.iconText %></th>
			<th><%= window.WPV_ADMIN.iconLink %></th>
		</tr>
	</table>
	<a href="#" class="add-new-icon"><%= window.WPV_ADMIN.addNewIcon %></a>
</script>