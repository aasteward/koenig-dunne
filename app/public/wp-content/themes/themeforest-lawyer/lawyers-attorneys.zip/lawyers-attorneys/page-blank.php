<?php
/**
 * Single page template
 *
 * Template Name: Blank
 *
 * @package wpv
 * @subpackage lawyers-attorneys
 */

get_template_part('page');